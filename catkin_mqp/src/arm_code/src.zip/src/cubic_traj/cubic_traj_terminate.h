//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// cubic_traj_terminate.h
//
// Code generation for function 'cubic_traj_terminate'
//

#ifndef CUBIC_TRAJ_TERMINATE_H
#define CUBIC_TRAJ_TERMINATE_H

// Include files
//#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void cubic_traj_terminate();

#endif
// End of code generation (cubic_traj_terminate.h)
