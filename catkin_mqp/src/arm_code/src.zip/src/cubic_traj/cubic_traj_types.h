//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// cubic_traj_types.h
//
// Code generation for function 'cubic_traj'
//

#ifndef CUBIC_TRAJ_TYPES_H
#define CUBIC_TRAJ_TYPES_H

// Include files
//#include "rtwtypes.h"

#endif
// End of code generation (cubic_traj_types.h)
