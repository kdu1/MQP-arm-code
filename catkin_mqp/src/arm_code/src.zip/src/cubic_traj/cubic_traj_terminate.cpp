//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// cubic_traj_terminate.cpp
//
// Code generation for function 'cubic_traj_terminate'
//

// Include files
#include "cubic_traj_terminate.h"
#include "rt_nonfinite.h"

// Function Definitions
void cubic_traj_terminate()
{
}

// End of code generation (cubic_traj_terminate.cpp)
