//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// cubic_traj_data.h
//
// Code generation for function 'cubic_traj_data'
//

/*#ifndef CUBIC_TRAJ_DATA_H
#define CUBIC_TRAJ_DATA_H

// Include files
//#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif*/
// End of code generation (cubic_traj_data.h)
