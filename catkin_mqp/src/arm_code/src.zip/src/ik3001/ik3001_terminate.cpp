//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// ik3001_terminate.cpp
//
// Code generation for function 'ik3001_terminate'
//

// Include files
#include "ik3001_terminate.h"
#include "rt_nonfinite.h"

// Function Definitions
void ik3001_terminate()
{
}

// End of code generation (ik3001_terminate.cpp)
