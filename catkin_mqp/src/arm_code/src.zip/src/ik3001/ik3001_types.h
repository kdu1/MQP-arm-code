//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// ik3001_types.h
//
// Code generation for function 'ik3001'
//

#ifndef IK3001_TYPES_H
#define IK3001_TYPES_H

// Include files
//#include "rtwtypes.h"
#include <vector>

#endif
// End of code generation (ik3001_types.h)
