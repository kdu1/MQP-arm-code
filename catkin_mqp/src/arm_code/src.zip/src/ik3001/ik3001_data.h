//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// ik3001_data.h
//
// Code generation for function 'ik3001_data'
//

#ifndef IK3001_DATA_H
#define IK3001_DATA_H

// Include files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
// End of code generation (ik3001_data.h)
