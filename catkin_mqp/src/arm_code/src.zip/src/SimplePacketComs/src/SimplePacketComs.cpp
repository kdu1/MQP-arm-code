#include "SimplePacketComs.h"
#include "hidapi.h"


  /**
   * no stop this is not the hiddevice function this is hidapi
  */
//this function from hidapi.java has the same header as hid_write from hidapi, so I'm guessing it's 
//functionally the same
/*uint32_t write(unsigned char* device, unsigned char data, uint32_t len, unsigned char reportID){
	//not sure how the byte type connects with the numberofbytes stuff
	//also not sure where to initialize the new hid object - but now that I have this function do I need it?
	// Fail fast
    if (device == null || data == null) {
      return DEVICE_ERROR;
    }

    // Precondition checks
    if (data.length < len) {
      len = data.length;
    }

    WideStringBuffer report;

    // Put report ID into position 0 and fill out buffer
    report = new WideStringBuffer(len + 1);
    report.buffer[0] = reportId;
    if (len >= 1) {
      System.arraycopy(data, 0, report.buffer, 1, len);
    }

    //logTraffic(report, true);

	return hid_write(); //they use this exact same function in hid4java but with some extra stuff around it
}*/
SimplePacketComsAbstract::SimplePacketComsAbstract() {
	setNumberOfBytesInPacket(DEFAULT_PACKET_SIZE_SIMPLE_PACKET);

}
uint32_t SimplePacketComsAbstract::getNumberOfBytesInPacket() {
	return numberOfBytes;
}
void SimplePacketComsAbstract::setNumberOfBytesInPacket(
		uint32_t newNumberOfBytes) {
	numberOfBytes = newNumberOfBytes;
	buffer = new uint8_t[numberOfBytes];
}
uint32_t SimplePacketComsAbstract::getNumberOfFloatsInPacket() {
	return (numberOfBytes / 4) - 1;
}

void SimplePacketComsAbstract::attach(
		PacketEvent * eventImplementation) {
	fmap[eventImplementation->getId()] = eventImplementation;
}

PacketEvent * SimplePacketComsAbstract::detach(uint32_t id) {
	PacketEvent *event = fmap[id];
	fmap.erase(id);
	return event;
}

/**
 * This runs the packet server and calls all events if a backet comes in
 */
void SimplePacketComsAbstract::server() {
	for (std::map<uint32_t, PacketEvent*>::iterator it = fmap.begin();
			it != fmap.end(); ++it) {
		it->second->loop();
	}
	if (isPacketAvailible()) {
		getPacket(buffer, numberOfBytes);
		uint32_t currentId = getIdPointer()[0];
		for (std::map<uint32_t, PacketEvent*>::iterator it =
				fmap.begin(); it != fmap.end(); ++it) {
			if (it->second->getId() == currentId) {
				it->second->noResponse = false; // reset the response flag
				it->second->event(getDataPointer());

				if (it->second->noResponse == false) {
					// respond unless the no response flag is set
					sendPacket(buffer, numberOfBytes);
				}

				return; // packet is responded to, fast return
			}
		}

		//printf("\nUnknown packet %i ",currentId);
		for (int i = 0; i < 4; i++) {
			//copy the incoming missing ID into data
			buffer[i + 4] = buffer[i];
		}
		//write in error ID
		buffer[0] = 99;
		buffer[1] = 0;
		buffer[2] = 0;
		buffer[3] = 0; //error packet
		// Zero out the rest of packet
		for (int i = 8; i < numberOfBytes; i++) {
			buffer[i] = 0;
		}

		sendPacket(buffer, numberOfBytes);
		return;
	}
}
/**
 * This pushes a packet upstream
 */
void SimplePacketComsAbstract::push(uint32_t id, float * bufferofFloats) {
	getIdPointer()[0] = id;
	float * outgoingBuff = getDataPointer();
	for (uint32_t i = 0; i < getNumberOfFloatsInPacket(); i++) {
		outgoingBuff[i] = bufferofFloats[i];
	}
	sendPacket(buffer, numberOfBytes);
}
