#include <stdexcept>
/***
 * serves as a wrapper for Hidapi
 * given that hid4java is a java wrapper, it might be I can just directly call hid_write from
 * the hidapi instead
*/

/**
   * @return True if the device structure is not present (device closed)
   * @since 0.8.0
*/
/*bool isClosed() {
    return hidDeviceStructure == NULL;
}

/**
 * read and write
 * next two from hidDevice, which calls HidApi, which calls the actual hid_write
 * key is to try to figure out what these are doing and what is necessary
*/
/*uint32_t write(unsigned char* message, int packetLength, unsigned char reportId) {
    if (isClosed()) {
      throw std::invalid_argument( "Device has not been opened" );
    }
    return write(message, packetLength, reportId, false);
  }

//unsigned char subsitute for bytes
uint32_t write(unsigned char* message, int packetLength, unsigned char reportId, bool applyPadding) {
    if (isClosed()) {
        throw std::invalid_argument( "Device has not been opened" );
    }

    if (applyPadding) {
        int len = packetLength + 1;
        message = unsigned char [len];
        //message = Arrays.copyOf(message, packetLength + 1);
        std::copy(std::begin(message), std::end(message), std::begin(message));
    }

    int result = HidApi.write(hidDeviceStructure, message, packetLength, reportId);
    // Update HID manager
    hidDeviceManager.afterDeviceWrite(); //really not sure what to do with this stuff
	//it involes a thread or something. Wondering if it is necessary to use at all
    return result;

  }*/